using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Blood : MonoBehaviour
{
    public Image _Blood;

    public void updateBlood(float luongMauHienTai, float luongMauToiDa)
    {
        _Blood.fillAmount = luongMauHienTai / luongMauToiDa;
    }
}

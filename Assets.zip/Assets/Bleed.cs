using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public Blood blood;

    public float luongMauHienTai;

    public float luongMauToiDa = 10;
    void Start()
    {
        luongMauHienTai = luongMauToiDa;
        blood.updateBlood(luongMauHienTai, luongMauToiDa);
    }

    private void OnMouseDown()
    {
        luongMauHienTai -= 2;
        blood.updateBlood(luongMauHienTai, luongMauToiDa);
        if(luongMauHienTai < 0) 
        {
            Destroy(this.gameObject);
        }
    }
}
